library(shiny)
library(shinydashboard)
library(shinyWidgets)
library(shinycustomloader)
library(deSolve)
library(reshape2)
library(ggplot2)
library(gridExtra)
library(grid)
library(MASS)
library(plyr)
library(compiler)
library(doParallel)
library("shinybusy")


# UI ---- 
ui <- dashboardPage(
  title = "Reogrelor Case Study",
  
  # Header
  dashboardHeader(
    title = h4("Reogrelor Case Study", style = "text-align: center; font-size:20px; font-family:'helvetica'; color:'aqua';"),
    titleWidth = 250
  ),
  
  # Sidebar
  dashboardSidebar(
    width = 250,

    h6(strong('Patient Characteristics'), style = "text-align: center; font-size:13px; font-family:'helvetica'; color:white;"),
    sliderInput("n", 'Number of subjects', min = 0, max = 250, value = 100, step = 1, ticks = F),
    fluidRow(
      column(6, numericInput("min_WT", HTML("Minimum weight [kg]"), value = 50)),
      column(6, numericInput("max_WT", "Maximum weight [kg]", value = 120))
    ),
    
    hr(),
    h6(strong('Treatment Details'), style = "text-align: center; font-size:13px; font-family:'helvetica'; color:white;"),
    sliderInput("dose_CNG_1", "Startin Bolus Dose [μg/kg]", min = 1, max = 50, value = 30, step = 0.5, ticks = F),
    sliderInput("dose_Infusion", "Infusion Dose [μg/kg/min]", min = 1, max = 10, value = 4, step = 0.5, ticks = F),
    sliderInput("interval_1", "Infusion duration [hours]", min = 1, max = 3, value = 1, step = 0.5, ticks = F),
    
    hr(),
    h6(strong('Measurement Details'), style = "text-align: center; font-size:13px; font-family:'helvetica'; color:white;"),
    sliderInput("Samples", "Number of Samples", min = 1, max = 24, value = 10, step = 1, ticks = F),
    textInput("time_points", "Sampling times [hours] (comma-separated)", value = "0, 0.1, 0.2, 0.5, 0.8, 1, 1.5, 1.8, 2, 3"),
    
    fluidPage(
      hr(style = "border-color:gray;"),
      h5('Models by: P. Laddomada, U. Villani, A. Di Deo, O. Della Pasqua', style = "color:gray;"),
      h5('Created by:A. Di Deo', style = "color:gray;")
    )
  ),
  
  # Body
  dashboardBody(

    sidebarMenu(
      menuItem("Clinical Trial Design", icon = icon("line-chart"), selected = TRUE, tabName = "pkpd_sim1")
    ),
    br(),
    
    tabItems(
      tabItem(tabName = "pkpd_sim1", tags$style(HTML(".box-header .box-title {
        text-align: center; width: 100%; font-family:'helvetica;
      }
    ")),
              fluidRow(
                # Plot 1 Card
                box(
                  title = strong("Predicted Reogrelor Concentration"),
                  status = "primary",
                  solidHeader = TRUE,
                  width = 4,
                  withLoader(plotOutput("plotCONC", height = 450, width = 370),
                             type = "image",
                             loader = 'https://img.pikbest.com/png-images/20190918/cartoon-snail-loading-loading-gif-animation_2734139.png!bw700')
                ),
                
                # Plot 2 Card
                box(
                  title = strong("Predicted Platelet Aggregation (%)"),
                  status = "warning",
                  solidHeader = TRUE,
                  width = 4,
                  withLoader(plotOutput("plotPLT", height = 450, width = 370),
                             type = "image",
                             loader = 'https://img.pikbest.com/png-images/20190918/cartoon-snail-loading-loading-gif-animation_2734139.png!bw700')
                ),
                
                # Plot 3 Card
                box(
                  title = strong("Predicted Response Rate (%)"),
                  status = "success",
                  solidHeader = TRUE,
                  width = 4,
                  withLoader(plotOutput("plotRESP", height = 450, width = 370),
                             type = "image",
                             loader = 'https://img.pikbest.com/png-images/20190918/cartoon-snail-loading-loading-gif-animation_2734139.png!bw700')
                ),
                hr(),
                div(
                  style = "text-align: center; margin-top: 18px;",
                  actionButton("Simulate", "Simulate", icon = icon("paper-plane"))
                ),
              )
      )
    )
  )
)



# Summary Functions ---
sumfuncx <- function(x) {
  stat1 <-  median(x)
  stat2 <-  quantile(x, probs=0.05, names=F) 
  stat3 <-  quantile(x, probs=0.95, names=F)
  stat4 <-  length(x)
  result <- c("median"=stat1, "low"=stat2, "hi"=stat3, "n"=stat4)
  result
}

perc_resp <- function(x) {
  perc <- c('perc1' = sum(x>0.90)/length(x)*100, 'perc2' = sum(x>0.8)/length(x)*100, 'perc3' = sum(x>0.7)/length(x)*100, 'n' = length(x))
  perc
}



# SERVER ----
server <- function(input, output, session) {
  
  
  mod1 <- eventReactive(input$Simulate, {
    
    #Create a dataframe with ID and parameter values for each individual	
    n <- input$n
    par.data <- seq(from = 1, to = n, by = 1)
    par.data <- data.frame(par.data)
    set.seed(02072024)
    WT <- runif(n, min = input$min_WT, max = input$max_WT)
    names(par.data)[1] <- "ID"
    
    #Define population values
    
    #PK Cangrelor
    TVCL_CNG = 39.4
    TVV1_CNG = 3.3
    
    #PD Platelet Inhibition
    TVKIN = 1
    TVKOUT = 0
    TVIC50 = 16.0
    
    
    #Define population parameter variability
    
    #PK Cangrelor
    ETACL_CNG <- rnorm(n, mean = 0, sd = sqrt(0.06))  #0.06
    ETAV1_CNG <- rnorm(n, mean = 0, sd = sqrt(0.09))  #0.09
    
    #PD Platelet Inhibition
    ETAIC50 = rnorm(n, mean = 0, sd = sqrt(0.4))
    #ETAKOUT = rnorm(n, mean = 0, sd = sqrt(0.6))
    
    #Simulate individual values	
    #PK Cangrelor
    par.data$CL_CNG = TVCL_CNG * (WT/70)^0.75 * exp(ETACL_CNG)
    par.data$V1_CNG = TVV1_CNG * (WT/70) * exp(ETAV1_CNG)
    
    #PD Platelet Inhibition
    par.data$KIN = TVKIN 
    par.data$KOUT = TVKOUT
    par.data$IC50 = TVIC50 * exp(ETAIC50)
    par.data$WT = WT
    
    TIME <- sort(
      unique(
        as.numeric(
          unlist(strsplit(input$time_points, ","))
        )
      )
    )
    
    platelet_mod <- function(t, S, parameters) {
      with(as.list(c(S, parameters)), {
        
        ### ODE system
        dSdt=vector(len=3)
        
        ### PK Cangrelor
        Ke_CNG = CL_CNG/V1_CNG
        
        # Infusion rate (0 before, during T_inf it's Dose_inf / T_inf, 0 after)
        R_inf <- ifelse(t <= interval_1, dose_Infusion*WT*60/interval_1, 0)
        
        # Central compartment
        dSdt[1] = R_inf - Ke_CNG * S[1]
        
        # AUC
        dSdt[2] = S[1]/V1_CNG
        
        # C/Css
        C_CNG = S[1]/V1_CNG
        Cavg_CNG = ifelse(S[2] == 0, yes = 1e-10, no = S[2]/t)
        
        ### PD Platelet Inhibition
        INH = C_CNG/(C_CNG+IC50)
        
        # Platelet compartment
        dSdt[3] = KIN * (1 - INH) - KOUT*S[3]
        
        list(dSdt)
      })
    }
    
    
    th.cmpf <- cmpfun(platelet_mod)
    #----------------------------------------------------------------------------------------	
    #Function for simulating concentrations for the ith patient
    simulate.conc <- function(par.data, dose_CNG_1, interval_1, dose_Infusion, treat_dur) {
      
      par <- c(par.data, dose_Infusion = dose_Infusion, interval_1 = interval_1)
      
      #Set initial conditions in each compartment
      S = c(
        S1 = 0,
        S2 = 0,
        S3 = 1
      )
      
      events_dataset <- rbind(data.frame(var = c("S1"), time=0, value = dose_CNG_1*par.data$WT, method=c("add")),
                              data.frame(var = c("S1"), time=0, value = dose_Infusion*par.data$WT, method=c("add")))
      
      sim.data <- lsoda(y = S, 
                        times = TIME, 
                        func = th.cmpf, 
                        parms = par,
                        atol = 1e-3,
                        ynames = F,
                        rtol	= 1e-3,
                        events	= list(data=events_dataset))
      
      sim.data <- as.data.frame(sim.data)	
    }
    
    #Compile simulate.conc function	
    simulate.conc.cmpf <- cmpfun(simulate.conc)
    
    #Apply simulate.conc.cmpf function to each individual in par.data
    #ID is provided as a variable in which each value has simulate.conc.cmpf applied to
    #V1 and V2 are required to be here to preserve their values, so concentrations can be
    #calculated later
    suppressWarnings({
      sim.data <- ddply(par.data, .(ID, V1_CNG, IC50), simulate.conc.cmpf, 
                        dose_CNG_1 = input$dose_CNG_1,
                        dose_Infusion = input$dose_Infusion,
                        interval_1 = input$interval_1,
                        treat_dur = 12)
    })
    
    sim.data$Cavg_CNG <- sim.data$S2/(sim.data$time+1e-10)
    sim.data$CONC_CNG <- sim.data$S1/sim.data$V1_CNG
    sim.data$PLAT_INH <- 1 * (1-(sim.data$CONC_CNG/(sim.data$CONC_CNG+sim.data$IC50)))
    
    
    suppressWarnings({
      statsCONC_CNG <- ddply(sim.data, 
                             .(time), function(sim.data) sumfuncx(sim.data$CONC_CNG))
      statsCONC_CNG$time <- (statsCONC_CNG$time)
      statsPLT <- ddply(sim.data, 
                        .(time), function(sim.data) sumfuncx(1-sim.data$PLAT_INH))
      statsRESP <- ddply(sim.data, 
                         .(time), function(sim.data) perc_resp(1-sim.data$PLAT_INH))
    })
    
    #Combine datasets
    list(
      conc = statsCONC_CNG,
      PLT  = statsPLT,
      RESP = statsRESP
    )
    
    
  })
  
  output$plotCONC <- renderPlot({
    req(input$Simulate > 0)
    
    df <- mod1()$conc
    
    ggplot(df, aes(x = time*60, y = median)) +
      geom_line(size = 1.2, colour = "steelblue") +
      geom_ribbon(aes(ymin = low, ymax = hi),
                  fill = "steelblue", alpha = 0.3) +
      scale_x_continuous(breaks = seq(0, 180, 30)) +
      scale_y_continuous(breaks = seq(0, 1000, 100)) +
      labs(y = "Reogrelor Plasma Concentration [ng/mL]", x = "Time Since Start of Infusion [min]") +
      theme_bw() +
      theme(
        plot.background = element_rect(fill = '#ecf0f4', colour = '#ecf0f4'),
        axis.title = element_text(size = 14),
        axis.text = element_text(size = 12))
    
  })
  
  output$plotPLT <- renderPlot({
    req(input$Simulate > 0)
    
    df <- mod1()$PLT
    
    ggplot(df, aes(x = time*60, y = median*100)) +
      geom_line(size = 1.2, colour = "chocolate4") +
      geom_ribbon(aes(ymin = low*100, ymax = hi*100),
                  fill = "chocolate3", alpha = 0.3) +
      scale_x_continuous(breaks = seq(0, 180, 30)) +
      labs(y = "Platelet Inhibition [%]", x = "Time Since Start of Infusion [min]") +
      geom_hline(yintercept = c(80, 90), linetype =2) +
      theme_bw() +
      theme(
        plot.background = element_rect(fill = '#ecf0f4', colour = '#ecf0f4'),
        axis.title = element_text(size = 14),
        axis.text = element_text(size = 12)) +
      annotate("text", x=160, y=92.5, label="Inhibition 90%", size = 4, fontface = "italic")+
      annotate("text", x=160, y=82.5, label="Inhibition 80%", size = 4, fontface = "italic")
    
    
  })
  
  output$plotRESP <- renderPlot({
    req(input$Simulate > 0)
    
    df <- mod1()$RESP
    
    x_lab <- max(df$time * 60)
    
    ggplot() +
      geom_line(data = df, aes(x = time*60, y = perc1), size = 1.4, colour = "darkseagreen4") +
      geom_line(data = df, aes(x = time*60, y = perc2), size = 1.4, colour = "darkseagreen") +
      geom_line(data = df, aes(x = time*60, y = perc3), size = 1.4, colour = "darkseagreen3") +
      scale_x_continuous(breaks = seq(0, 180, 30)) +
      labs(y = "Percentage of Responders [%]", x = "Time Since Start of Infusion [min]") +
      theme_bw() +
      theme(
        plot.background = element_rect(fill = '#ecf0f4', colour = '#ecf0f4'),
        axis.title = element_text(size = 15),
        axis.text = element_text(size = 13)) +
      annotate("text", x = x_lab, y = 95,
               label = "Platelet Aggregate\n Inhibition ~90%", colour = "darkseagreen4",
               hjust = 1.05, size = 4.5, fontface = "bold") +
      annotate("text", x = x_lab, y = 80,
               label = "Platelet Aggregate\n  Inhibition ~80%", colour = "darkseagreen",
               hjust = 1.05, size = 4.5, fontface = "bold") +
      annotate("text", x = x_lab, y = 65,
               label = "Platelet Aggregate\n  Inhibition ~70%", colour = "darkseagreen3",
               hjust = 1.05, size = 4.5, fontface = "bold")
  })
  
}

### EXECUTE APP
shinyApp(ui, server)




## ============================================================================
## Haemoglobinopathies Case Study — optimised Shiny app
##
## Optimisation summary
## ---------------------------------------------------------------------------
## 1. Everything that does NOT depend on user input (ODE model definitions,
##    their compiler::cmpfun() compilation, population ("TV") constants, and
##    the summary helpers) now lives at the top level of the script, i.e. it
##    runs ONCE when the app starts — not once per "Simulate" click as in the
##    original, where thalassemia_mod()/simulate.conc() were rebuilt and
##    recompiled inside reactive() on every run.
## 2. The four near-identical ODE variants are refactored to share a single
##    compiled core (pk_pd_core()) for the PK part, removing ~80% code
##    duplication while keeping the exact compartment numbering/semantics of
##    the original four functions.
## 3. plyr::ddply(..., .parallel = TRUE) + foreach/doParallel is replaced by
##    future::plan(cluster, ...) + furrr::future_map(), which explicitly
##    resolves globals needed on the workers (more robust than relying on
##    foreach's implicit export).
## 4. reshape2::melt()/rbind(transform(...)) bookkeeping is replaced by
##    dplyr::group_by()/summarise() and dplyr::bind_rows().
## ============================================================================

# ---- Libraries --------------------------------------------------------------
library(shiny)
library(shinydashboard)
library(shinyWidgets)
library(shinycustomloader)
library(deSolve)
library(ggplot2)
library(MASS)        # mvrnorm
library(dplyr)
library(purrr)
library(furrr)
library(future)
library(compiler)
library(parallel)

# ---- Parallel backend (created once, shared by all sessions) ---------------
n_workers <- max(1, parallel::detectCores() - 1)
cl <- parallel::makeCluster(n_workers)
parallel::clusterEvalQ(cl, library(deSolve))
future::plan(future::cluster, workers = cl)

# Make sure the cluster is torn down when the app process stops
shiny::onStop(function() {
  try(parallel::stopCluster(cl), silent = TRUE)
})

# ---- Fixed population (typical-value) parameters ---------------------------
# PK deferasirox (DFX)
TVKa_DFX <- 0.11
TVCL_DFX <- 1.75
TVV2_DFX <- 21.1
TVQ_DFX  <- 1.93
TVV3_DFX <- 15.2
TVF1_DFX <- 0.7

# PK deferiprone (DFP)
TVKa_DFP <- 9.13
TVCL_DFP <- 8.30
TVV_DFP  <- 18.7

# PD ferritin
TVFERMAX <- 11.7e3
TVFER50  <- 1.24e3
TVslope_eff_DFX <- 0.00128 / (30 * 24)
TVslope_eff_DFP <- 0.0109  / (30 * 24)

# Inter-individual variability (fixed magnitudes, independent of input)
OMEGA_CL_DFX <- sqrt(0.23)
OMEGA_V2_DFX <- sqrt(0.40)
OMEGA_Ka_DFX <- sqrt(1.4)
OMEGA_V3_DFX <- sqrt(2.12)
SIGMA_CL_V_DFP <- matrix(c(6.44e-02, 3.92e-02, 3.92e-02, 3.10e-02), 2, 2)
OMEGA_slope_eff_DFP_1 <- sqrt(0.109)
OMEGA_slope_eff_DFP_2 <- sqrt(0.437)
OMEGA_BLOODCONS <- sqrt(0.462)

# ---- Shared compiled PK/PD core (used by all 4 ODE variants) ---------------
# Computes the first 9 derivatives (DFX/DFP absorption, central, peripheral,
# AUC compartments, and the two "untouched" iron pools) plus the
# concentration-driven effect terms needed by the iron compartments that
# differ between the four switch combinations.
pk_pd_core <- function(t, S, p) {
  Ke_DFX  <- p$CL_DFX / p$V2_DFX
  K23_DFX <- p$Q_DFX  / p$V2_DFX
  K32_DFX <- p$Q_DFX  / p$V3_DFX
  Ke_DFP  <- p$CL_DFP / p$V_DFP
  
  dS1 <- -p$Ka_DFX * S[1]
  dS2 <-  p$Ka_DFX * S[1] - Ke_DFX * S[2] - K23_DFX * S[2] + K32_DFX * S[3]
  dS3 <-  K23_DFX * S[2] - K32_DFX * S[3]
  dS4 <-  S[2] / p$V2_DFX
  
  dS5 <- -p$Ka_DFP * S[5]
  dS6 <-  p$Ka_DFP * S[5] - Ke_DFP * S[6]
  dS7 <-  S[6] / p$V_DFP
  
  Cavg_DFX <- if (S[4] == 0) 1e-10 else S[4] / t
  Cavg_DFP <- if (S[7] == 0) 1e-10 else S[7] / t
  EFF_DFX  <- Cavg_DFX * p$slope_eff_DFX
  EFF_DFP  <- Cavg_DFP * p$slope_eff_DFP
  
  dS8 <- 1.16 * p$BLOODCONS - EFF_DFX * S[8]
  dS9 <- 1.16 * p$BLOODCONS - EFF_DFP * S[9]
  
  list(
    d        = c(dS1, dS2, dS3, dS4, dS5, dS6, dS7, dS8, dS9),
    EFF_DFX  = EFF_DFX,
    EFF_DFP  = EFF_DFP
  )
}
pk_pd_core_cmp <- compiler::cmpfun(pk_pd_core)

# ---- The four ODE variants (defined & compiled ONCE) ------------------------

# Neither titration nor drug switch (9 states)
thalassemia_mod_none <- function(t, S, parameters) {
  core <- pk_pd_core_cmp(t, S, parameters)
  list(core$d)
}

# Drug switch only (11 states: + DFX->DFP iron pool & its flag)
thalassemia_mod_drug <- function(t, S, parameters) {
  p    <- parameters
  core <- pk_pd_core_cmp(t, S, p)
  
  FER_conv <- p$FERMAX * S[10] / (p$FER50 + S[10])
  
  dS11 <- 0
  if (t < p$TIME_SWITCH_DRUG) {
    EFF_COM <- core$EFF_DFX
  } else if (S[11] <= 0 && t >= p$TIME_SWITCH_DRUG &&
             (FER_conv < 2500 || (FER_conv - p$FERBASE) / p$FERBASE <= -0.2)) {
    EFF_COM <- core$EFF_DFX
  } else {
    EFF_COM <- core$EFF_DFP
    dS11 <- 1
  }
  dS10 <- 1.16 * p$BLOODCONS - EFF_COM * S[10]
  
  list(c(core$d, dS10, dS11))
}

# Dose titration only (13 states: + titrated DFX/DFP flags & iron pools)
thalassemia_mod_dose <- function(t, S, parameters) {
  p    <- parameters
  core <- pk_pd_core_cmp(t, S, p)
  
  FER_DFX_TIT_conv <- p$FERMAX * S[12] / (p$FER50 + S[12])
  FER_DFP_TIT_conv <- p$FERMAX * S[13] / (p$FER50 + S[13])
  
  dS10 <- 0
  if (t < p$TIME_SWITCH_DOSE) {
    EFF_DFX_TIT <- core$EFF_DFX
  } else if (S[10] <= 0 && t >= p$TIME_SWITCH_DOSE &&
             (FER_DFX_TIT_conv < 2500 || (FER_DFX_TIT_conv - p$FERBASE) / p$FERBASE <= -0.2)) {
    EFF_DFX_TIT <- core$EFF_DFX
  } else {
    EFF_DFX_TIT <- core$EFF_DFX * p$dose_ratio_DFX
    dS10 <- 1
  }
  
  dS11 <- 0
  if (t < p$TIME_SWITCH_DOSE) {
    EFF_DFP_TIT <- core$EFF_DFP
  } else if (S[11] <= 0 && t >= p$TIME_SWITCH_DOSE &&
             (FER_DFP_TIT_conv < 2500 || (FER_DFP_TIT_conv - p$FERBASE) / p$FERBASE <= -0.2)) {
    EFF_DFP_TIT <- core$EFF_DFP
  } else {
    EFF_DFP_TIT <- core$EFF_DFP * p$dose_ratio_DFP
    dS11 <- 1
  }
  
  dS12 <- 1.16 * p$BLOODCONS - EFF_DFX_TIT * S[12]
  dS13 <- 1.16 * p$BLOODCONS - EFF_DFP_TIT * S[13]
  
  list(c(core$d, dS10, dS11, dS12, dS13))
}

# Dose titration AND drug switch (15 states)
thalassemia_mod_full <- function(t, S, parameters) {
  p    <- parameters
  core <- pk_pd_core_cmp(t, S, p)
  
  FER_DFX_DFP_conv <- p$FERMAX * S[10] / (p$FER50 + S[10])
  
  dS11 <- 0
  if (t < p$TIME_SWITCH_DRUG) {
    EFF_COM <- core$EFF_DFX
  } else if (S[11] <= 0 && t >= p$TIME_SWITCH_DRUG &&
             (FER_DFX_DFP_conv < 2500 || (FER_DFX_DFP_conv - p$FERBASE) / p$FERBASE <= -0.2)) {
    EFF_COM <- core$EFF_DFX
  } else {
    EFF_COM <- core$EFF_DFP
    dS11 <- 1
  }
  dS10 <- 1.16 * p$BLOODCONS - EFF_COM * S[10]
  
  FER_DFX_TIT_conv <- p$FERMAX * S[14] / (p$FER50 + S[14])
  FER_DFP_TIT_conv <- p$FERMAX * S[15] / (p$FER50 + S[15])
  
  dS12 <- 0
  if (t < p$TIME_SWITCH_DOSE) {
    EFF_DFX_TIT <- core$EFF_DFX
  } else if (S[12] <= 0 && t >= p$TIME_SWITCH_DOSE &&
             (FER_DFX_TIT_conv < 2500 || (FER_DFX_TIT_conv - p$FERBASE) / p$FERBASE <= -0.2)) {
    EFF_DFX_TIT <- core$EFF_DFX
  } else {
    EFF_DFX_TIT <- core$EFF_DFX * p$dose_ratio_DFX
    dS12 <- 1
  }
  
  dS13 <- 0
  if (t < p$TIME_SWITCH_DOSE) {
    EFF_DFP_TIT <- core$EFF_DFP
  } else if (S[13] <= 0 && t >= p$TIME_SWITCH_DOSE &&
             (FER_DFP_TIT_conv < 2500 || (FER_DFP_TIT_conv - p$FERBASE) / p$FERBASE <= -0.2)) {
    EFF_DFP_TIT <- core$EFF_DFP
  } else {
    EFF_DFP_TIT <- core$EFF_DFP * p$dose_ratio_DFP
    dS13 <- 1
  }
  
  dS14 <- 1.16 * p$BLOODCONS - EFF_DFX_TIT * S[14]
  dS15 <- 1.16 * p$BLOODCONS - EFF_DFP_TIT * S[15]
  
  list(c(core$d, dS10, dS11, dS12, dS13, dS14, dS15))
}

# Compile each variant exactly once at app startup
mod_none_cmp <- compiler::cmpfun(thalassemia_mod_none)
mod_drug_cmp <- compiler::cmpfun(thalassemia_mod_drug)
mod_dose_cmp <- compiler::cmpfun(thalassemia_mod_dose)
mod_full_cmp <- compiler::cmpfun(thalassemia_mod_full)

select_model <- function(dose_switch, drug_switch) {
  if (dose_switch && drug_switch)        mod_full_cmp
  else if (!dose_switch && !drug_switch) mod_none_cmp
  else if (!dose_switch && drug_switch)  mod_drug_cmp
  else                                   mod_dose_cmp
}

# ---- Initial-state builder (static logic, depends only on switches+FERBASE) -
build_initial_state <- function(dose_switch, drug_switch, fer_base) {
  fer0 <- (TVFER50 * fer_base) / (TVFERMAX - fer_base)
  
  if (dose_switch && drug_switch) {
    c(S1 = 0, S2 = 0, S3 = 0, S4 = 0, S5 = 0, S6 = 0, S7 = 0,
      S8 = fer0, S9 = fer0, S10 = fer0, S11 = 0, S12 = 0, S13 = 0,
      S14 = fer0, S15 = fer0)
  } else if (!dose_switch && !drug_switch) {
    c(S1 = 0, S2 = 0, S3 = 0, S4 = 0, S5 = 0, S6 = 0, S7 = 0,
      S8 = fer0, S9 = fer0)
  } else if (!dose_switch && drug_switch) {
    c(S1 = 0, S2 = 0, S3 = 0, S4 = 0, S5 = 0, S6 = 0, S7 = 0,
      S8 = fer0, S9 = fer0, S10 = fer0, S11 = 0)
  } else {
    c(S1 = 0, S2 = 0, S3 = 0, S4 = 0, S5 = 0, S6 = 0, S7 = 0,
      S8 = fer0, S9 = fer0, S10 = 0, S11 = 0, S12 = fer0, S13 = fer0)
  }
}

# ---- Per-subject simulation (static logic, compiled once) -------------------
simulate_subject <- function(par_row, model_fn, TIME, dose_DFX_1, dose_DFP_1,
                             dfx_dose_times, dfp_dose_times, S0) {
  events_dataset <- data.frame(
    var    = c(rep("S1", length(dfx_dose_times)), rep("S5", length(dfp_dose_times))),
    time   = c(dfx_dose_times, dfp_dose_times),
    value  = c(rep(dose_DFX_1 * par_row$WT, length(dfx_dose_times)),
               rep(dose_DFP_1 * par_row$WT, length(dfp_dose_times))),
    method = "add"
  )
  
  out <- deSolve::lsoda(
    y      = S0,
    times  = TIME,
    func   = model_fn,
    parms  = par_row,
    atol   = 1e-3,
    rtol   = 1e-3,
    ynames = FALSE,
    events = list(data = events_dataset)
  )
  
  as.data.frame(out) |>
    dplyr::mutate(ID = par_row$ID, V2_DFX = par_row$V2_DFX, V_DFP = par_row$V_DFP)
}
simulate_subject_cmp <- compiler::cmpfun(simulate_subject)

# ---- Summary helper (replaces sumfuncx()/perc_resp() + ddply) ---------------
summarise_var <- function(df, var, label_state, label_drug,
                          type = c("level", "percent"), window = NULL) {
  type <- match.arg(type)
  
  if (!is.null(window)) {
    df <- df |>
      dplyr::filter(time >= window[1], time <= window[2]) |>
      dplyr::mutate(time = (time - window[1]) * 30 * 24)
  }
  
  df |>
    dplyr::group_by(time) |>
    dplyr::summarise(
      median = if (type == "percent") mean(.data[[var]]) * 100 else stats::median(.data[[var]]),
      low    = if (type == "percent") NA_real_ else stats::quantile(.data[[var]], probs = 0.05, names = FALSE),
      hi     = if (type == "percent") NA_real_ else stats::quantile(.data[[var]], probs = 0.95, names = FALSE),
      n      = dplyr::n(),
      .groups = "drop"
    ) |>
    dplyr::mutate(state = label_state, drug = label_drug)
}

# ---- UI ----------------------------------------------------------------------
ui <- dashboardPage(
  title = "Haemoglobinopathies Case Study",
  dashboardHeader(
    title = h4("Haemoglobinopathies Case Study", style = "font-family:'helvetica'; color:'aqua';"),
    titleWidth = 320
  ),
  dashboardSidebar(
    width = 320,
    sidebarMenu(
      menuItem("Graphs", icon = icon("line-chart"), selected = TRUE, tabName = "pkpd_sim1")
    ),
    fluidPage(
      h5('', style = "padding:350px;"),
      hr(style = "border-color:gray;"),
      h5('Models by: A. Di Deo, S. Oosterholt, F. Bellanti, E. Borella, P. Magni, M. Danhof, O. Della Pasqua',
         style = "color:gray;"),
      h5("Created by: S. D'Agate and A. Di Deo", style = "color:gray;")
    )
  ),
  dashboardBody(
    tabItems(
      tabItem(
        tabName = "pkpd_sim1",
        fluidRow(
          column(width = 9, withLoader(plotOutput("plotCONC", height = 627), type = 'image',
                                       loader = 'https://img.pikbest.com/png-images/20190918/cartoon-snail-loading-loading-gif-animation_2734139.png!bw700')),
          column(
            width = 3,
            sliderInput("n", HTML('Number of subjects'),
                        min = 0, max = 100, value = 10, step = 1, ticks = FALSE),
            fluidRow(
              column(6, numericInput("min_WT", HTML("Mininum weight [kg]"), value = 10)),
              column(6, numericInput("max_WT", "Maximum weight [kg]", value = 120))
            ),
            sliderInput("interval_1", "Treatment duration [months]",
                        min = 3, max = 24, value = 12, step = 1, ticks = FALSE),
            fluidRow(
              column(6, numericInput("dose_DFX_1", HTML("Initial DFX dose [mg/kg]"), value = 14)),
              column(6, numericInput("dose_DFP_1", "Initial DFP dose [mg/kg]", value = 25))
            ),
            hr(style = "border-color:lightgray;"),
            prettySwitch("dose_switch", HTML("Titrate non-responders' doses?"), value = FALSE),
            sliderInput("time_switch_dose", HTML('Time of dose titration'),
                        min = 3, max = 12, value = 6, step = 3, ticks = FALSE),
            fluidRow(
              column(6, numericInput("dose_DFX_2", HTML("Titrated DFX dose [mg/kg]"), value = 28)),
              column(6, numericInput("dose_DFP_2", "Titrated DFP dose [mg/kg]", value = 50))
            ),
            hr(style = "border-color:lightgray;"),
            prettySwitch("drug_switch", HTML('Switch DFX non-responders to DFP?'), value = FALSE),
            sliderInput("time_switch_drug", HTML('Time of drug switch'),
                        min = 3, max = 12, value = 6, step = 3, ticks = FALSE),
            hr(style = "border-color:lightgray;"),
            sliderInput("fer_base", HTML('Baseline ferritin [ng/mL]'),
                        min = 0.1, max = 10000, value = 4000, step = 100, ticks = FALSE),
            sliderInput("blood_cons", HTML('Blood consumption [mL/kg/month]'),
                        min = 0.1, max = 20, value = 12.5, step = 1, ticks = FALSE),
            submitButton("Simulate")
          )
        )
      )
    )
  )
)

# ---- SERVER ------------------------------------------------------------------
server <- function(input, output, session) {
  
  mod1 <- reactive({
    
    n   <- input$n
    set.seed(02072024)
    WT  <- runif(n, min = input$min_WT, max = input$max_WT)
    
    fer_base   <- input$fer_base
    treat_dur  <- input$interval_1 * 30 * 24
    dose_DFX_1 <- input$dose_DFX_1
    dose_DFP_1 <- input$dose_DFP_1
    dose_switch <- input$dose_switch
    drug_switch <- input$drug_switch
    
    # ---- Inter-individual variability draws (vectorised) ----
    ETACL_DFX <- rnorm(n, 0, OMEGA_CL_DFX)
    ETAV2_DFX <- rnorm(n, 0, OMEGA_V2_DFX)
    ETAKa_DFX <- rnorm(n, 0, OMEGA_Ka_DFX)
    ETAV3_DFX <- rnorm(n, 0, OMEGA_V3_DFX)
    
    ETA_CL_V_DFP <- MASS::mvrnorm(n, mu = rep(0, 2), Sigma = SIGMA_CL_V_DFP)
    ETACL_DFP <- ETA_CL_V_DFP[, 1]
    ETAV_DFP  <- ETA_CL_V_DFP[, 2]
    
    ETAslope_eff_DFP <- rnorm(n, 0, OMEGA_slope_eff_DFP_1) + rnorm(n, 0, OMEGA_slope_eff_DFP_2)
    ETABLOODCONS     <- rnorm(n, 0, OMEGA_BLOODCONS)
    
    # ---- Individual parameter table (tidyverse) ----
    par.data <- tibble::tibble(
      ID     = seq_len(n),
      WT     = WT,
      CL_DFX = TVCL_DFX * (WT / 70)^0.75 * exp(ETACL_DFX),
      V2_DFX = TVV2_DFX * (WT / 70) * exp(ETAV2_DFX),
      Ka_DFX = TVKa_DFX * exp(ETAKa_DFX),
      V3_DFX = TVV3_DFX * (WT / 70) * exp(ETAV3_DFX),
      Q_DFX  = TVQ_DFX  * (WT / 70)^0.75,
      CL_DFP = TVCL_DFP * (WT / 15.75)^0.75 * exp(ETACL_DFP),
      V_DFP  = TVV_DFP  * (WT / 15.75) * exp(ETAV_DFP),
      Ka_DFP = TVKa_DFP,
      FERMAX = TVFERMAX,
      FER50  = TVFER50,
      slope_eff_DFX = TVslope_eff_DFX,
      FERBASE = fer_base,
      slope_eff_DFP = TVslope_eff_DFP * exp(ETAslope_eff_DFP),
      BLOODCONS = (input$blood_cons / (30 * 24)) * exp(ETABLOODCONS),
      TIME_SWITCH_DRUG = input$time_switch_drug * 30 * 24,
      TIME_SWITCH_DOSE = input$time_switch_dose * 30 * 24,
      dose_ratio_DFX = input$dose_DFX_2 / input$dose_DFX_1,
      dose_ratio_DFP = input$dose_DFP_2 / input$dose_DFP_1
    )
    
    TIME <- sort(unique(c(
      seq(0, treat_dur, by = 24 / 3),
      seq(treat_dur - 24, treat_dur, by = 1)
    )))
    
    dfx_dose_times <- seq(0, treat_dur, by = 24)
    dfp_dose_times <- seq(0, treat_dur, by = 24 / 3)
    
    model_fn <- select_model(dose_switch, drug_switch)
    S0       <- build_initial_state(dose_switch, drug_switch, fer_base)
    
    # ---- Parallel per-subject simulation (furrr instead of plyr+foreach) ----
    par_list <- purrr::pmap(par.data, list)
    
    sim.data <- furrr::future_map(
      par_list, simulate_subject_cmp,
      model_fn = model_fn, TIME = TIME,
      dose_DFX_1 = dose_DFX_1, dose_DFP_1 = dose_DFP_1,
      dfx_dose_times = dfx_dose_times, dfp_dose_times = dfp_dose_times,
      S0 = S0,
      .options = furrr::furrr_options(seed = TRUE)
    ) |>
      dplyr::bind_rows()
    
    # ---- Derived quantities ----
    sim.data <- sim.data |>
      dplyr::mutate(
        Cavg_DFX = S4 / (time + 1e-10),
        Cavg_DFP = S7 / (time + 1e-10),
        CONC_DFX = S2 / V2_DFX,
        CONC_DFP = S6 / V_DFP,
        FER_DFX  = TVFERMAX * S8 / (TVFER50 + S8),
        FER_DFP  = TVFERMAX * S9 / (TVFER50 + S9),
        resp_DFX = as.integer(FER_DFX < 2500 | (FER_DFX - fer_base) / fer_base <= -0.2),
        resp_DFP = as.integer(FER_DFP < 2500 | (FER_DFP - fer_base) / fer_base <= -0.2)
      )
    
    if (dose_switch && drug_switch) {
      sim.data <- sim.data |>
        dplyr::mutate(
          CONC_TIT_DFX = CONC_DFX * input$dose_DFX_2 / input$dose_DFX_1,
          CONC_TIT_DFP = CONC_DFP * input$dose_DFP_2 / input$dose_DFP_1,
          FER_TIT_DFX  = TVFERMAX * S14 / (TVFER50 + S14),
          FER_TIT_DFP  = TVFERMAX * S15 / (TVFER50 + S15),
          resp_TIT_DFX = as.integer(FER_TIT_DFX < 2500 | (FER_TIT_DFX - fer_base) / fer_base <= -0.2),
          resp_TIT_DFP = as.integer(FER_TIT_DFP < 2500 | (FER_TIT_DFP - fer_base) / fer_base <= -0.2)
        )
    }
    if (dose_switch && !drug_switch) {
      sim.data <- sim.data |>
        dplyr::mutate(
          CONC_TIT_DFX = CONC_DFX * input$dose_DFX_2 / input$dose_DFX_1,
          CONC_TIT_DFP = CONC_DFP * input$dose_DFP_2 / input$dose_DFP_1,
          FER_TIT_DFX  = TVFERMAX * S12 / (TVFER50 + S12),
          FER_TIT_DFP  = TVFERMAX * S13 / (TVFER50 + S13),
          resp_TIT_DFX = as.integer(FER_TIT_DFX < 2500 | (FER_TIT_DFX - fer_base) / fer_base <= -0.2),
          resp_TIT_DFP = as.integer(FER_TIT_DFP < 2500 | (FER_TIT_DFP - fer_base) / fer_base <= -0.2)
        )
    }
    if (drug_switch) {
      sim.data <- sim.data |>
        dplyr::mutate(
          FER_DFX_DFP  = TVFERMAX * S10 / (TVFER50 + S10),
          resp_DFX_DFP = as.integer(FER_DFX_DFP < 2500 | (FER_DFX_DFP - fer_base) / fer_base <= -0.2)
        )
    }
    
    # ---- Summarise & combine (dplyr instead of ddply + rbind/transform) ----
    ss_window <- c(treat_dur - 24, treat_dur)
    
    if (dose_switch && drug_switch) {
      result <- dplyr::bind_rows(
        summarise_var(sim.data, "CONC_DFX",     "DFX concentration at SS [mg/L]", "DFX",            "level", ss_window),
        summarise_var(sim.data, "CONC_DFP",     "DFP concentration at SS [mg/L]", "DFP",            "level", ss_window),
        summarise_var(sim.data, "CONC_TIT_DFX", "DFX concentration at SS [mg/L]", "Titrated DFX",   "level", ss_window),
        summarise_var(sim.data, "CONC_TIT_DFP", "DFP concentration at SS [mg/L]", "Titrated DFP",   "level", ss_window),
        summarise_var(sim.data, "FER_DFX",      "Ferritin [ng/mL]", "DFX",                 "level"),
        summarise_var(sim.data, "FER_DFP",      "Ferritin [ng/mL]", "DFP",                 "level"),
        summarise_var(sim.data, "FER_TIT_DFX",  "Ferritin [ng/mL]", "Titrated DFX",        "level"),
        summarise_var(sim.data, "FER_TIT_DFP",  "Ferritin [ng/mL]", "Titrated DFP",        "level"),
        summarise_var(sim.data, "FER_DFX_DFP",  "Ferritin [ng/mL]", "DFX switched to DFP", "level"),
        summarise_var(sim.data, "resp_DFX",     "Responders [%]", "DFX",                  "percent"),
        summarise_var(sim.data, "resp_DFP",     "Responders [%]", "DFP",                  "percent"),
        summarise_var(sim.data, "resp_TIT_DFX", "Responders [%]", "Titrated DFX",         "percent"),
        summarise_var(sim.data, "resp_TIT_DFP", "Responders [%]", "Titrated DFP",         "percent"),
        summarise_var(sim.data, "resp_DFX_DFP", "Responders [%]", "DFX switched to DFP",  "percent")
      )
    } else if (!dose_switch && !drug_switch) {
      result <- dplyr::bind_rows(
        summarise_var(sim.data, "CONC_DFX", "DFX concentration at SS [mg/L]", "DFX", "level", ss_window),
        summarise_var(sim.data, "CONC_DFP", "DFP concentration at SS [mg/L]", "DFP", "level", ss_window),
        summarise_var(sim.data, "FER_DFX",  "Ferritin [ng/mL]", "DFX",  "level"),
        summarise_var(sim.data, "FER_DFP",  "Ferritin [ng/mL]", "DFP",  "level"),
        summarise_var(sim.data, "resp_DFX", "Responders [%]", "DFX",   "percent"),
        summarise_var(sim.data, "resp_DFP", "Responders [%]", "DFP",   "percent")
      )
    } else if (!dose_switch && drug_switch) {
      result <- dplyr::bind_rows(
        summarise_var(sim.data, "CONC_DFX",    "DFX concentration at SS [mg/L]", "DFX", "level", ss_window),
        summarise_var(sim.data, "CONC_DFP",    "DFP concentration at SS [mg/L]", "DFP", "level", ss_window),
        summarise_var(sim.data, "FER_DFX",     "Ferritin [ng/mL]", "DFX",                 "level"),
        summarise_var(sim.data, "FER_DFP",     "Ferritin [ng/mL]", "DFP",                 "level"),
        summarise_var(sim.data, "FER_DFX_DFP", "Ferritin [ng/mL]", "DFX switched to DFP", "level"),
        summarise_var(sim.data, "resp_DFX",    "Responders [%]", "DFX",                  "percent"),
        summarise_var(sim.data, "resp_DFP",    "Responders [%]", "DFP",                  "percent"),
        summarise_var(sim.data, "resp_DFX_DFP","Responders [%]", "DFX switched to DFP",   "percent")
      )
    } else {
      result <- dplyr::bind_rows(
        summarise_var(sim.data, "CONC_DFX",     "DFX concentration at SS [mg/L]", "DFX",          "level", ss_window),
        summarise_var(sim.data, "CONC_DFP",     "DFP concentration at SS [mg/L]", "DFP",          "level", ss_window),
        summarise_var(sim.data, "CONC_TIT_DFX", "DFX concentration at SS [mg/L]", "Titrated DFX", "level", ss_window),
        summarise_var(sim.data, "CONC_TIT_DFP", "DFP concentration at SS [mg/L]", "Titrated DFP", "level", ss_window),
        summarise_var(sim.data, "FER_DFX",      "Ferritin [ng/mL]", "DFX",          "level"),
        summarise_var(sim.data, "FER_DFP",      "Ferritin [ng/mL]", "DFP",          "level"),
        summarise_var(sim.data, "FER_TIT_DFX",  "Ferritin [ng/mL]", "Titrated DFX", "level"),
        summarise_var(sim.data, "FER_TIT_DFP",  "Ferritin [ng/mL]", "Titrated DFP", "level"),
        summarise_var(sim.data, "resp_DFX",     "Responders [%]", "DFX",           "percent"),
        summarise_var(sim.data, "resp_DFP",     "Responders [%]", "DFP",           "percent"),
        summarise_var(sim.data, "resp_TIT_DFX", "Responders [%]", "Titrated DFX",  "percent"),
        summarise_var(sim.data, "resp_TIT_DFP", "Responders [%]", "Titrated DFP",  "percent")
      )
    }
    
    result
  })
  
  output$plotCONC <- renderPlot({
    plotobj <- ggplot(mod1()) +
      geom_line(aes(x = time / (30 * 24), y = median, col = drug), size = 1) +
      geom_ribbon(aes(x = time / (30 * 24), ymin = low, ymax = hi, fill = drug), alpha = 0.3) +
      scale_y_continuous("") +
      scale_x_continuous("\nTime [\u2191hours/\u2193months]") +
      facet_wrap(~state, nrow = 2, scales = 'free') +
      scale_color_discrete('') +
      scale_fill_discrete('') +
      theme_bw() +
      theme(
        plot.background = element_rect(fill = '#ecf0f4', colour = '#ecf0f4'),
        legend.background = element_rect(fill = '#ecf0f4', colour = '#ecf0f4')
      )
    suppressWarnings(print(plotobj))
  })
}

### EXECUTE APP
shinyApp(ui, server)